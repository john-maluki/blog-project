# from django.test import TestCase
# from django.urls import reverse


# class ContactTests(TestCase):
#     def test_contact_url_state(self):
#         response = self.client.get(reverse('contact:contact'))
#         self.assertEqual(response.status_code, 200)
        # self.assertTemplateUsed(response, 'contact/contact.html')

    # def test_post_detail_view(self):
    #     response = self.client.get('/post/1/')
    #     no_response = self.client.get('/post/10000/')
    #     self.assertEqual(response.status_code, 200)
    #     self.assertEqual(no_response.status_code, 404)
    #     self.assertContains(response, 'A good title')
