# from django.contrib.auth import get_user_model
# from django.test import TestCase, Client
# from django.urls import reverse


# class ViewsTests(TestCase):
#     def test_home_view(self):
#         user_login = self.client.login(email="user@mp.com", password="user")
#         self.assertTrue(user_login)
